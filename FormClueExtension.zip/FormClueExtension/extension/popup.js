// popup.js (optional, empty or basic info-only popup)
document.addEventListener("DOMContentLoaded", () => {
  const status = document.getElementById("status");
  status.textContent = "FormClue is active. AI suggestions will appear below each question.";
});
